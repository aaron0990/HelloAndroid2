package com.jediupc.helloandroid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CompassView extends View{

    Paint mPaint = new Paint();
    private float mX;
    private float mY;



    public CompassView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mPaint.setColor(Color.parseColor("#ff0000"));
        mPaint.setStrokeWidth(8);

    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float h = getHeight();
        float w = getWidth();

        canvas.drawLine(w/4, h/4, (w/2)*(mX*100), (h/2)*(mY*100), mPaint);

        invalidate();
    }

    public void setXY(float x, float y) {
        mX = x;
        mY = y;

    }


}
