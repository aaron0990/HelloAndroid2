package com.jediupc.helloandroid;

public class MenuItem {
    public String title;
    public Class cls;

    public MenuItem (String title, Class cls){
        this.title = title;
        this.cls = cls;
    }
}
