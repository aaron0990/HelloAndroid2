package com.jediupc.helloandroid;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity  implements View.OnClickListener{


    public static final String KEY_USERNAME = "username";
    public static final String KEY_SETTINGS = "settings";

    Button mbLogin;
    EditText metUser;
    EditText metPass;
    CheckBox mcbRemember;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Hasta que no se llame a onCreate, no se inicializa nada.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SharedPreferences sp = getSharedPreferences(KEY_SETTINGS, MODE_PRIVATE);

        if(sp.contains(KEY_USERNAME)){
            Log.d("LoginActivity", "Already have username, skipping login");
            startContentActivity();
            return;
        }

        mbLogin = findViewById(R.id.bLogin);
        metUser = findViewById(R.id.etUser);
        metPass = findViewById(R.id.etPass);
        mcbRemember = findViewById(R.id.cbRemember);

        mbLogin.setOnClickListener(LoginActivity.this);

    }

    @Override
    public void onClick(View view) {
        Log.d("LoginActivity", metUser.getText().toString());
        Log.d("LoginActivity", metPass.getText().toString());
        Log.d("LoginActivity", mcbRemember.isChecked()?"remember" : "don't remember");
        Log.d("LoginActivity", "Login!");

        if (mcbRemember.isChecked()){
            SharedPreferences sp = getSharedPreferences(KEY_SETTINGS, MODE_PRIVATE); //Solo permite leer de momento
            sp.edit().putString(KEY_USERNAME, metUser.getText().toString()).apply(); //nos da un editor, le asignamos el valor de nuestro user y con apply le decimos que lo guarde cuando tenga tiempo


        }
        startContentActivity();
    }

    private void startContentActivity() {
        Intent i = new Intent(this, ListActivity.class);
        startActivity(i);
        finish(); //para acabar la activity y si se tira para atras en la nueva, no volver a esta.
    }
}
