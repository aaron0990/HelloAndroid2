package com.jediupc.helloandroid;

import android.content.Context;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class CompassActivity extends AppCompatActivity implements SensorEventListener{

    SensorManager mSensorManager;
    Sensor mMagnetometer;
    CompassView mCompassView;
    private float maxRange;

    //Cuando se llama al onCreate sabemos que se llamará al onStart y al onResume()
    //Cuando se llama a onStop, siempre se habrá llamado previamente a onPause


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compass);

        mCompassView = findViewById(R.id.compassView);
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mMagnetometer = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener( this, mMagnetometer, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        mCompassView.setXY(sensorEvent.values[0], sensorEvent.values[1]);

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
