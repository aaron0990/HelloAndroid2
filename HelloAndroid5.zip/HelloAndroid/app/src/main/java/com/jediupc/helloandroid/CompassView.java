package com.jediupc.helloandroid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Size;
import android.view.View;

public class CompassView extends View{

    Paint mPaintBorder = new Paint();
    Paint mPaintBall = new Paint();
    private float ang;

    public CompassView(Context context, AttributeSet attrs) {
        super(context, attrs);

        mPaintBorder.setColor(Color.parseColor("#ff0000"));
        mPaintBorder.setStrokeWidth(8);
        mPaintBorder.setStyle(Paint.Style.STROKE);

        mPaintBall.setColor(Color.parseColor("#ff0000"));
        mPaintBall.setStrokeWidth(8);


    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int h = getHeight();
        int w = getWidth();
        int smallest = Math.min(h, w);
        float cc = (smallest/3)-(smallest/9);
        canvas.drawCircle(w / 2 , h / 2 , smallest/3 , mPaintBorder);
        canvas.drawCircle((float) (w/2 + (cc*Math.sin((double)ang))), (float) ((h/2)+ (cc*Math.cos((double)ang))), smallest/9, mPaintBall);

        invalidate();
    }

    public void setAng(float ang) {
        this.ang = ang;
    }

}
